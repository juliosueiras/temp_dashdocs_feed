$('body').append(
    '<div id="qunit"></div>' +
    '<div id="qunit-fixture"></div>'
);
